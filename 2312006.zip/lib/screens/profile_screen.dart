import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _infoRow(
              icon: Icons.person,
              text: 'Name: Nguyễn Công Hoàng',
            ),
            _infoRow(
              icon: Icons.email,
              text: 'Email: cacomfpt@fe.edu.vn',
            ),
            _infoRow(
              icon: Icons.palette,
              iconColor: Colors.pink,
              text: 'Favorite Color: cyan',
            ),
            _infoRow(
              icon: Icons.thumb_up,
              iconColor: Colors.green,
              text:
                  'Strength: Positive attitude and leadership skills.',
            ),
            _infoRow(
              icon: Icons.warning,
              iconColor: Colors.orange,
              text:
                  'Weakness: Does not manage emotions well.',
            ),
            const Spacer(),
            Center(
              child: FilledButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.home),
                label: const Text('Back to Home'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoRow({
    required IconData icon,
    required String text,
    Color? iconColor,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: iconColor),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 18),
            ),
          ),
        ],
      ),
    );
  }
}
