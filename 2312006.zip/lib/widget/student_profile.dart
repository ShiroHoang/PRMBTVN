import 'package:flutter/material.dart';

class Student {
  final String? imageUrl;
  final String studentId;
  final String name;
  final String email;
  final String phone;
  final String address;

  Student({
    this.imageUrl,
    required this.studentId,
    required this.name,
    required this.email,
    required this.phone,
    required this.address,
  });
}


class StudentProfile extends StatelessWidget{

  StudentProfile({super.key});

  final List<Student> students = [
    Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Nguyen Cong Hoang',
      email: 'cacomfpt@fe.edu.vn',
      phone: '0123456789',
      address: 'Ha Noi',
    ),
    Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Con vit mau vang',
      email: 'yeloduck@fe.edu.vn',
      phone: '019824321',
      address: 'Sai Gon',
    ),
    Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),Student(
      imageUrl: 'https://hips.hearstapps.com/hmg-prod/images/call-duck-695733614-67f4fc458cf92.jpg?crop=0.668xw:1.00xh;0.181xw,0&resize=980:*',
      studentId: '001',
      name: 'Duong Duc Anh',
      email: 'ducanhngo@fe.edu.vn',
      phone: '022442211',
      address: 'Thanh Pho HCM',
    ),
  ];


  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      appBar: AppBar(
        title: Text("Student Profile"),
      ),
      body: ListView.separated(
        itemCount: students.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(students[index].imageUrl ?? ''),
            ),
            title: Text("Name: ${students[index].name}"),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Student ID: ${students[index].studentId}"),
                Text("Email: ${students[index].email}"),
                Text("Address: ${students[index].address}"),
              ],),
            trailing: Text(students[index].phone),
          );
        },
        separatorBuilder: (context, index) => const Divider(),
      ),
    );
  }
  
}